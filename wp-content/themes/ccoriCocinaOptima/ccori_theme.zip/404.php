<?php get_header(); ?>

<main class="darkHeader">
    <section class="error404">
        <h1 class="error404__title">
            Página no encontrada</h1>
    </section>
</main>

<?php get_footer(); ?>