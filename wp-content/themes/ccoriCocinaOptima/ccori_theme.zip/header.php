<!DOCTYPE html>
<html lang="es">

<head>
    <base href="https://ccori.org.pe">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <?php if (!wp_title("", false)) { ?>
        <title>Ccori | Home</title>
    <?php } else { ?>
        <title><?php wp_title(); ?></title>
    <?php    } ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@6.5.95/css/materialdesignicons.min.css">
    <?php wp_head(); ?>
</head>

<body class="drawer-opened">
    <header class="row">
        <div class="backdrop"></div>
        <h1>
            <a class="logo" href="https://ccori.org.pe"><img src="img/logo.png" alt="Ccori"></a>
        </h1>
        <nav>
            <div class="logo">
                <a href="https://ccori.org.pe"><img src="img/logo.png" alt="Ccori"></a>

                <button class="close-drawer-btn">
                    <img src="img/close.svg">
                </button>
            </div>
            <ul>
                <li>
                    <a href="todos-somos-ccori.html">Todos somos CCORI</a>
                </li>
                <li>
                    <a href="nuestra-mision.html">Nuestra misión</a>
                </li>
                <li class="has-submenu">
                    <a href="investigacion-y-desarrollo.html">
                        Investigación & desarrollo
                        <img src="img/header-caret-down.svg" alt="Investigación & desarrollo">
                    </a>
                    <ul>
                        <li class="arrow"></li>
                        <li>
                            <a href="investigacion-y-desarrollo.html#sabrosos-insectos-peruanos">Sabrosos insectos peruanos</a>
                        </li>
                        <li>
                            <a href="investigacion-y-desarrollo.html#relevancia-nutricional">Relevancia nutricional</a>
                        </li>
                        <li>
                            <a href="investigacion-y-desarrollo.html#chocolate-optimo">Chocolate óptimo</a>
                        </li>
                        <li>
                            <a href="investigacion-y-desarrollo.html#ajies-del-peru">Ajíes del Perú</a>
                        </li>
                        <li>
                            <a href="investigacion-y-desarrollo.html#maletines-y-fundas">Maletines y fundas</a>
                        </li>
                    </ul>
                </li>
                <li class="has-submenu">
                    <a href="programas-sociales.html">
                        Programas sociales
                        <img src="img/header-caret-down.svg" alt="Programas sociales">
                    </a>
                    <ul>
                        <li class="arrow"></li>
                        <li>
                            <a href="programas-sociales.html#cocinas-bondadosas">Cocinas bondadosas</a>
                        </li>
                        <li>
                            <a href="programas-sociales.html#cocina-optimista">Cocina optimista</a>
                        </li>
                        <li>
                            <a href="programas-sociales.html#malambo-sabroso">Malambo sabroso</a>
                        </li>
                        <li>
                            <a href="programas-sociales.html#talleres-vivenciales">Talleres vivenciales</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a class="btn btn-turquoise btn-fluid" href="donar.html">Donar</a>
                </li>
            </ul>
        </nav>

        <button class="open-drawer-btn">
            <img src="img/menu.svg">
        </button>
    </header>