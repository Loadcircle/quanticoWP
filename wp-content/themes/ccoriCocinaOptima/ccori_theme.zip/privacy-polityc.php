<?php get_header();
/* Template name: Plantilla General */
?>

<main>
    <section class="generalSection">
        <div class="general__container">
            <?php the_content(); ?>
        </div>
    </section>
</main>


<?php get_footer(); ?>