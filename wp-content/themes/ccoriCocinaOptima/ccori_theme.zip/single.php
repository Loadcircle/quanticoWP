<?php get_header(); ?>

<main class="darkHeader">
    <section class="fullNote">
        <div class="fullNote__container">
            <div class="fullnote__thumbnail">
                <?php if (has_post_thumbnail()) {
                    the_post_thumbnail();
                } ?>
            </div>



            <?php if (have_posts()) : ?>
                <?php while (have_posts()) : the_post(); ?>
                    <div>
                        <!-- post date -->
                        <p class="note__date note__date--full">
                            <?php the_date(); ?>
                        </p>

                        <!-- post title  -->
                        <h1 class="noteContent__title noteContent__title--full"><?php the_title(); ?> </h1>

                        <!-- post category -->
                        <p class="noteContent__category">
                            <?php $categories = get_the_category();
                            if (!empty($categories)) {
                                echo esc_html($categories[0]->name);
                            } ?>
                        </p>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>

            <div class="fullNote__content">
                <?php the_content(); ?>
            </div>

        </div>
    </section>
</main>


<?php get_footer(); ?>