<?php
/* Template Name: Donar */
get_header();
?>
<main class="donar-page">
    <div class="container">
        <h2 class="page_title">DONAR</h2>
    </div>

    <section class="green-hero-image row">
        <div class="container">
            <p>Con la compra de cada producto CCORI generas apoyo a nuestros programas sociales de capacitación en alimentación cero desperdicio y cocina óptima a comedores sociales peruanos.</p>
            <div class="img">
                <img src="/img/donar/banner.png" alt="">
            </div>
        </div>
        <div class="bg"></div>
    </section>
    <div class="container">
        <section class="store-product-grid">
            <div class="product">
                <div class="img">
                    <img src="/img/donar/maletin-negro-1.png" alt="Maletín de cuchillos - negro">
                </div>
                <div class="info">
                    <h3>Maletín de cuchillos - negro</h2>
                        <p class="price">S/ 600.00</p>
                        <a href="/producto/item-50.html" class="btn">Ver mas</a>
                </div>
            </div>
            <div class="product">
                <div class="img">
                    <img src="/img/donar/maletin-cafe-1.png" alt="Maletín de cuchillos - café">
                </div>
                <div class="info">
                    <h3>Maletín de cuchillos - café</h2>
                        <p class="price">S/ 600.00</p>
                        <a href="/producto/item-51.html" class="btn">Ver mas</a>
                </div>
            </div>
            <div class="product">
                <div class="img">
                    <img src="/img/donar/maletin-beige-1.png" alt="Maletín de cuchillos - beige">
                </div>
                <div class="info">
                    <h3>Maletín de cuchillos - beige</h2>
                        <p class="price">S/ 600.00</p>
                        <a href="/producto/item-52.html" class="btn">Ver mas</a>
                </div>
            </div>
            <div class="product">
                <div class="img">
                    <img src="/img/donar/polo-negro-1.png" alt="Polo Ccori - negro">
                </div>
                <div class="info">
                    <h3>Polo Ccori - negro</h2>
                        <p class="price">S/ 60.00</p>
                        <a href="/producto/item-53.html" class="btn">Ver mas</a>
                </div>
            </div>
            <div class="product">
                <div class="img">
                    <img src="/img/donar/polo-blanco-1.png" alt="Polo Ccori - blanco">
                </div>
                <div class="info">
                    <h3>Polo Ccori - blanco</h2>
                        <p class="price">S/ 60.00</p>
                        <a href="/producto/item-54.html" class="btn">Ver mas</a>
                </div>
            </div>
            <div class="product">
                <div class="img">
                    <img src="/img/donar/gorra-1.png" alt="Gorra trucker Ccori">
                </div>
                <div class="info">
                    <h3>Gorra trucker Ccori</h2>
                        <p class="price">S/ 29.00</p>
                        <a href="/producto/item-55.html" class="btn">Ver mas</a>
                </div>
            </div>
            <div class="product">
                <div class="img">
                    <img src="/img/donar/pack-1.png" alt="Ccori pack">
                </div>
                <div class="info">
                    <h3>Ccori pack</h2>
                        <p class="price">S/ 89.00</p>
                        <a href="/producto/item-56.html" class="btn">Ver mas</a>
                </div>
            </div>
            <div class="product">
                <div class="img">
                    <img src="/img/donar/insectos-1.png" alt="Sabrosos Insectos Peruanos">
                </div>
                <div class="info">
                    <h3>Sabrosos Insectos Peruanos</h2>
                        <p class="price">S/ 35.00</p>
                        <a href="/producto/item-57.html" class="btn">Ver mas</a>
                </div>
            </div>
        </section>
    </div>
</main>

<?php get_footer(); ?>