<?php
/* Template Name: Home */
get_header();
?>

<main class="home-page">

    <section class="hero row">
        <div class="container">
            <h2>TODOS SOMOS CCORI</h2>
            <p>Cada año en el mundo, una tercera parte de los alimentos se pierde y desperdicia. En paralelo, 800 millones de personas padecen hambre. Desde el 2013, CCORI ha desarrollado metodologías gastronómicas denominadas <strong>COCINA ÓPTIMA y RECICLAJE CULINARIO</strong>, cuyo objetivo es el máximo aprovechamiento de los alimentos.</p>
            <img src="/img/home/1.png" alt="TODOS SOMOS CCORI">
            <a class="btn" href="/todos-somos-ccori.html">Ver más</a>
        </div>
    </section>
    <section class="green-block row">
        <div class="container text-center">
            <h2>NUESTRA MISIÓN</h2>
            <p>CCORI es la primera organización peruana que nace con la misión de promover la sostenibilidad alimentaria a través de la COCINA ÓPTIMA.</p> <a class="btn" href="/nuestra-mision.html">Ver más</a>
        </div>
    </section>
    <section class="image-block row sided left">
        <div class="container">
            <div class="image" style="background-image: url(/img/home/2.png);"></div>
            <div class="info">
                <h2>INVESTIGACIÓN & DESARROLLO</h2>
                <p>Mediante alianzas y consultorías con agentes del área pública, privada y académica, CCORI contribuye en la generación de productos, servicios e investigaciones que fomentan la sustentabilidad.</p>
                <a class="btn" href="/investigacion-y-desarrollo.html">Ver más</a>
            </div>
        </div>
    </section>
    <section class="image-block row sided right">
        <div class="container">
            <div class="image" style="background-image: url(/img/home/3.png);"></div>
            <div class="info">
                <h2>PROGRAMAS SOCIALES</h2>
                <p>A través de diversos programas educativos que concientizan acerca de los beneficios en la aplicación de los fundamentos de la Cocina Óptima, CCORI busca contribuir en el trabajo por alcanzar la seguridad y sostenibilidad alimentaria del Perú.</p>
                <a class="btn" href="/programas-sociales.html">Ver más</a>
            </div>
        </div>
    </section>
    <section class="dark-image-block row">
        <div class="container">
            <h2>CONSULTORÍA Y ASISTENCIA TÉCNICA</h2>
            <p>Siendo en CCORI los pioneros y líderes en materia de Cocina Óptima y Reciclaje Culinario. Brindamos los servicios de consultoría, planes educativos y codiseño de productos para diversas entidades que buscan promover la Sostenibilidad en torno a la alimentación. ¿Estás interesado?</p>
            <a class="btn btn-turquoise" href="mailto:tribu@ccori.org.pe">Ver más</a>
            <img src="/img/home/4.png" alt="CONSULTORÍA Y ASISTENCIA TÉCNICA">
        </div>
    </section>
    <section class="recetas row">
        <div class="container">
            <h2>RECETAS ÓPTIMAS</h2>

            <div class="glide recetas__list">
                <div class="glide__track" data-glide-el="track">
                    <ul class="glide__slides">
                        <li class="glide__slide">
                            <a href="https://www.instagram.com/p/CcrDUl8ryaK/">
                                <img src="/img/ig/1.jpg">
                            </a>
                        </li>

                        <li class="glide__slide">
                            <a href="https://www.instagram.com/p/CcHXZmRNEXa/">
                                <img src="/img/ig/2.jpg">
                            </a>
                        </li>

                        <li class="glide__slide">
                            <a href="https://www.instagram.com/p/Cb0F3MBr_7e/">
                                <img src="/img/ig/3.jpg">
                            </a>
                        </li>

                        <li class="glide__slide">
                            <a href="https://www.instagram.com/p/Cbi4io3rw4a/">
                                <img src="/img/ig/4.jpg">
                            </a>
                        </li>

                    </ul>
                </div>

                <div class="glide__bullets" data-glide-el="controls[nav]">
                    <button class="glide__bullet" data-glide-dir="=0"></button>
                    <button class="glide__bullet" data-glide-dir="=1"></button>
                    <button class="glide__bullet" data-glide-dir="=2"></button>
                    <button class="glide__bullet" data-glide-dir="=3"></button>
                </div>


            </div>
    </section>

</main>


<?php get_footer(); ?>