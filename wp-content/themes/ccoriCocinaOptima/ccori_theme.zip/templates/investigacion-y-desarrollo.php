<?php
/* Template Name: Investigación y desarollo */
get_header();
?>

<main class="investigacion-y-desarrollo-page">

    <div class="container">
        <h2 class="page_title">INVESTIGACIÓN & DESARROLLO</h2>
        <p class="page_description">Mediante alianzas y consultorías con agentes del área pública, privada y académica, CCORI contribuye en la generación de productos, servicios e investigaciones que fomentan la sustentabilidad.</p>
    </div>

    <div class="tabs">
        <div class="tab-triggers">
            <div class="container"></div>
        </div>
        <div class="tab-pages">

            <!-- <div class="tab-page" id="sabrosos-insectos-peruanos" data-title="Sabrosos insectos peruanos">
    </div> -->

            <div class="tab-page" id="sabrosos-insectos-peruanos" data-title="Sabrosos insectos peruanos">
                <div class="green-center-image-hero row">
                    <div class="img">
                        <iframe src="https://www.youtube.com/embed/0RlO5QKsyFs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <div class="bg"></div>
                </div>
                <div class="container">
                    <p class="tab-page-description">Del Alimento Tradicional a la Innovación Gastronómica. Es un libro publicado en junio del año 2019, como parte del macroproyecto <strong>“Círculo de Investigación en Biodiversidad y Gastronomía”</strong> financiado por el FONDECYT (Fondo Nacional de Desarrollo Científico, Tecnológico y de Innovación Tecnológica).

                        En conjunto con la Universidad Peruana Cayetano Heredia (UPCH) y el Instituto de Investigación para el Desarrollo de Francia (IRD), esta publicación presenta los potenciales alimenticios y gastronómicos de los insectos que forman parte de la dieta de los habitantes de la Comunidad de Rumicallpa (San Martin, Perú), y de insectos que pueden ser criados en laboratorio.</p>
                </div>

                <section class="grid-images row">
                    <div class="container">
                        <div class="grid col-3">
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/sip-1.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/sip-2.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/sip-3.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/sip-4.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/sip-5.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/sip-6.png" alt="">
                            </div>
                        </div>
                    </div>
                </section>
                <div class="container">
                    <div class="news">
                        <h2>NOTICIAS</h2>
                        <button class="trigger-dropdown"></button>
                        <div class="list">
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/sip-n-1.png" alt="Presentan libro sobre insectos comestibles: " Sabrosos insectos peruanos"">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>Presentan libro sobre insectos comestibles: "Sabrosos insectos peruanos"</h2>
                                        <p>Con la presencia especial de la Vicepresidenta del Perú, Mercédes Aráoz, el Vicerrector de Investigación de la Universidad Peruana Cayetano Heredia (UPCH), Alejandro Bussalleu, y medios de comunicación y ...</p>
                                    </div>
                                    <a target="_blank" href="https://www.cayetano.edu.pe/cayetano/es/noticias/781-presentan-libro-sobre-insectos-comestibles-sabrosos-insectos-peruanos" class="btn">Ver más</a>
                                </div>
                            </section>
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/sip-n-2.png" alt="KYC lanza nuggets de pollo frito a base de plantas">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>KYC lanza nuggets de pollo frito a base de plantas</h2>
                                        <p>Kentucky Fried Chicken venderá un nuevo producto en su menú que no contiene pollo, pero sabe a pollo. La nueva alternativa de nugget de pollo frito a base de plantas, llamada Beyond Fried Chicken, se agreg...</p>
                                    </div>
                                    <a target="_blank" href="https://cnnespanol.cnn.com/video/kfc-nuggets-a-base-de-plantas-beyond-fried-chicken-vegetariano-pkg-cnn-dinero/" class="btn">Ver más</a>
                                </div>
                            </section>
                        </div>
                    </div>
                    <div class="books">
                        <h2>Libro Digital</h2>
                        <button class="trigger-dropdown"></button>
                        <div class="list">
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/sip-b-1.png" alt="Sabrosos insectos peruanos">
                                </div>
                                <div class="content">
                                    <h2>Sabrosos insectos peruanos</h2>
                                    <a target="_blank" href="https://issuu.com/michelired/docs/sabrosos_insectos_peruanos_normal_c" class="btn">Ver libro</a>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>

            </div>
            <div class="tab-page" id="relevancia-nutricional" data-title="Relevancia nutricional">
                <div class="green-center-image-hero row">
                    <div class="img">
                        <img src="/img/investigacion-desarrollo/1.png">
                    </div>
                    <div class="bg"></div>
                </div>
                <p class="tab-page-description container">Comprendiendo que la educación es el medio trascendental de difusión, CCORI permanentemente participa en charlas que promueven los fundamentos de la COCINA ÓPTIMA, y empíricamente en el desarrollo de programas educativos y manuales que contribuyen a la optimización de los recursos alimentarios.

                    En equipo con el Centro de Estudios e Innovación de Alimentos Funcionales (CEIAF) de la Universidad de Lima (ULIMA), se han realizado estudios conjuntos acerca de los valores nutricionales de <strong>diversos productos y plus productos de la biodiversidad peruana</strong>, y sus aplicaciones culinarias.</p>

                <section class="grid-images row">
                    <div class="container">
                        <div class="grid col-3">
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/rn-1.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/rn-2.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/rn-3.png" alt="">
                            </div>
                        </div>
                    </div>
                </section>
                <div class="container">
                    <div class="news">
                        <h2>NOTICIAS</h2>
                        <button class="trigger-dropdown"></button>
                        <div class="list">
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/rn-n-1.png" alt="" Reciclaje Culinario" para no desperdiciar la comida">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>"Reciclaje Culinario" para no desperdiciar la comida</h2>
                                        <p>El chef peruano Palmiro Ocampo quiere llevar la técnica del "reciclaje culinario" para ayudar a la sociedad, a los comedores públicos y los estudiantes a no desperdiciar la comida y comer delicioso.</p>
                                    </div>
                                    <a target="_blank" href="https://cnnespanol.cnn.com/video/cnnee-pkg-maria-elena-belaunde-peru-reciclaje-comida/" class="btn">Ver más</a>
                                </div>
                            </section>
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/rn-n-2.png" alt="Pamplinas y otros cuentos gastronómicos">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>Pamplinas y otros cuentos gastronómicos</h2>
                                        <p>Una experiencia iberoamericana basada en la sostenibilidad y con chefs estrellas Michelin y de referencia mundial en el sector.</p>
                                    </div>
                                    <a target="_blank" href="https://eventos.prodigiosovolcan.com/evento/pamplinas-gastronomia-sostenibilidad/" class="btn">Ver más</a>
                                </div>
                            </section>
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/rn-n-3.png" alt="Ciencia y gastronomía en un mismo platillo">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>Ciencia y gastronomía en un mismo platillo</h2>
                                        <p>Palmiro Ocampo convierte los residuos de frutas y verduras en delicias con alto valor nutricional. A sus recetas les ha incorporado los microencapsulados obtenidos en el proceso de elaboración de la bebida...</p>
                                    </div>
                                    <a target="_blank" href="https://www.ulima.edu.pe/departamento/ceiaf/noticias/ciencia-y-gastronomia-en-un-mismo-platillo" class="btn">Ver más</a>
                                </div>
                            </section>
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/rn-n-4.png" alt="Microencapsulación de aceites de sacha inchi">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>Microencapsulación de aceites de sacha inchi</h2>
                                        <p>El 4 de octubre se llevó a cabo la prueba de producto del proyecto “Microencapsulación de aceites de sacha inchi y antioxidantes de la biodiversidad peruana”, liderado por Nancy Chasquibol, docente e ...</p>
                                    </div>
                                    <a target="_blank" href="https://www.facebook.com/idiculima/posts/747421912404668" class="btn">Ver más</a>
                                </div>
                            </section>
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/rn-n-5.png" alt="Reciclaje gastronómico">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>Reciclaje gastronómico</h2>
                                        <p>Un tercio de los alimentos que se producen en el mundo se desperdicia, de acuerdo con FAO. El reciclaje de la comida fue el tema principal del diálogo ‘Gastronomía y Conservación’ que se realizó en el marco...</p>
                                    </div>
                                    <a target="_blank" href="https://www.eluniverso.com/vida/2018/08/22/nota/6916643/reciclaje-gastronomico/" class="btn">Ver más</a>
                                </div>
                            </section>
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/rn-n-6.png" alt="Pruebe las papas picantes de Perú">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>Pruebe las papas picantes de Perú</h2>
                                        <p>La agricultura industrializada ha amenazado la diversidad y el valor cultural de este cultivo básico, pero los chefs ingeniosos están cambiando la receta.</p>
                                    </div>
                                    <a target="_blank" href="https://www.nationalgeographic.com/magazine/article/get-a-taste-of-potatoes-in-peru" class="btn">Ver más</a>
                                </div>
                            </section>
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/rn-n-7.png" alt="Hambre Cero: Recetas y consejos para un Perú más fuerte">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>Hambre Cero: Recetas y consejos para un Perú más fuerte</h2>
                                        <p>“Hambre Cero: Recetas y consejos para un Perú más fuerte” es una publicación del Programa Mundial de Alimentos que evidencia el trabajo innovador de la Oficina de País, implementando acciones para promo...</p>
                                    </div>
                                    <a target="_blank" href="https://peru.un.org/es/141775-hambre-cero-recetas-y-consejos-para-un-peru-mas-fuerte" class="btn">Ver más</a>
                                </div>
                            </section>
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/rn-n-8.png" alt="Programa Cuna Más promueve el desarrollo infantil temprano con cuentos audiovisuales">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>Programa Cuna Más promueve el desarrollo infantil temprano con cuentos audiovisuales</h2>
                                        <p>Se busca promover conocimientos y prácticas que potencien la crianza de niñas y niños hasta los 36 meses de edad</p>
                                    </div>
                                    <a target="_blank" href="https://andina.pe/agencia/noticia-programa-cuna-mas-promueve-desarrollo-infantil-temprano-cuentos-audiovisuales-803915.aspx" class="btn">Ver más</a>
                                </div>
                            </section>
                        </div>
                    </div>
                    <div class="books">
                        <h2>PAPERS</h2>
                        <button class="trigger-dropdown"></button>
                        <div class="list">
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/rn-b-1.png" alt="Comedor la amistad">
                                </div>
                                <div class="content">
                                    <h2>Comedor la amistad</h2>
                                    <a target="_blank" href="https://drive.google.com/file/d/12a2_aK5RkCuX6e1D2JdXxN4AzEEdcUr7/view?usp=sharing" class="btn">Previsualizar</a>
                                </div>
                            </section>
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/rn-b-2.png" alt="Comedor virgen del rosario">
                                </div>
                                <div class="content">
                                    <h2>Comedor virgen del rosario</h2>
                                    <a target="_blank" href="https://drive.google.com/file/d/12ZFmwr5cPqu4EVX_4dVPlgdNjKljdi7n/view?usp=sharing" class="btn">Previsualizar</a>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-page" id="chocolate-optimo" data-title="Chocolate óptimo">
                <div class="green-center-image-hero row">
                    <div class="img">
                        <iframe src="https://www.youtube.com/embed/Z88iIKH3w74" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <div class="bg"></div>
                </div>
                <p class="tab-page-description container">Junto a los chocolateros de Magia Piura, que enaltecen la labor de los agricultores y el cacao blanco piurano, CCORI, se ha desarrollado <strong>un chocolate que se manifiesta rechazando el derroche de alimentos mediante el rescate de la piel de la papa Ambo.</strong> De las mismas manos de las Cocineras Bondadosas, lo que anteriormente fue considerado un desecho, surge un Plus Producto que se enlaza delicadamente en la confección de los más finos chocolates peruanos.</p>

                <section class="grid-images row">
                    <div class="container">
                        <div class="grid col-3">
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/co-1.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/co-2.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/co-3.png" alt="">
                            </div>
                        </div>
                    </div>
                </section>
                <div class="container">
                    <div class="news">
                        <h2>NOTICIAS</h2>
                        <button class="trigger-dropdown"></button>
                        <div class="list">
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/co-n-1.png" alt="Así es el chocolate con chicharrón de piel de papa amarilla del cocinero Palmiro Ocampo">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>Así es el chocolate con chicharrón de piel de papa amarilla del cocinero Palmiro Ocampo</h2>
                                        <p>“Se pueden optimizar más los alimentos y combatir su despilfarro”, propone. Perú21 entrevistó al cocinero Palmiro Ocampo.</p>
                                    </div>
                                    <a target="_blank" href="https://peru21.pe/cultura/asi-es-el-chocolate-con-chicharron-de-piel-de-papa-amarilla-del-cocinero-palmiro-ocampo-gastronomia-cacao-peruano-piura-noticia/" class="btn">Ver más</a>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-page" id="ajies-del-peru" data-title="Ajíes del Perú">
                <div class="green-center-image-hero row">
                    <div class="img">
                        <img src="/img/investigacion-desarrollo/2.png">
                    </div>
                    <div class="bg"></div>
                </div>
                <p class="tab-page-description container">Si bien en nuestro país se mantiene la mayor diversidad de ajíes cultivados del mundo, el Perú moderno, mayoritariamente urbano, ha reducido su consumo de ajíes a básicamente cinco tipos principales <strong>(amarillo, panca, rocoto, limo y charapita)</strong> y algunos pocos ajíes regionales. Aumentar la demanda de ajíes nativos puede ser la base de negocios rurales que permitan que pequeños agricultores y empresas coloquen sus ajíes nativos en mercados y hogares del Perú y el mundo. Los concursos de salsas picantes son una manera de involucrar a grupos organizados de mujeres que ya participan en cadenas culinarias populares en barrios de lima.</p>

                <section class="grid-images row">
                    <div class="container">
                        <div class="grid col-3">
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/ap-1.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/ap-2.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/ap-3.png" alt="">
                            </div>
                        </div>
                    </div>
                </section>
                <div class="container">
                    <div class="books">
                        <h2>PAPERS</h2>
                        <button class="trigger-dropdown"></button>
                        <div class="list">
                            <section>
                                <div class="img">
                                    <img src="/img/investigacion-desarrollo/ap-b-1.png" alt="Concurso de salsas picantes">
                                </div>
                                <div class="content">
                                    <h2>Concurso de salsas picantes</h2>
                                    <a target="_blank" href="https://drive.google.com/file/d/12_mfb6mRNbVuyYKONeocQN8syPD_45Uu/view?usp=sharing" class="btn">Previsualizar</a>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-page" id="maletines-y-fundas" data-title="Maletines y fundas">
                <div class="green-center-image-hero row">
                    <div class="img">
                        <img src="/img/investigacion-desarrollo/3.png">
                    </div>
                    <div class="bg"></div>
                </div>
                <p class="tab-page-description container">A través de una colaboración con QAYA Cueros de Pescado Peruanos, en búsqueda de recaudar fondos para los Programas Sociales, se desarrollaron y elaboraron maletines y fundas de cuchillo que <strong>optimizan al máximo la piel del pescado desechada de los terminales y mercados pesqueros.</strong></p>

                <section class="grid-images row">
                    <div class="container">
                        <div class="grid col-3">
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/mf-1.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/mf-2.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/investigacion-desarrollo/mf-3.png" alt="">
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>