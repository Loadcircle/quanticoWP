<?php
/* Template Name: Donar */
get_header();
?>
<main class="producto-page">

    <div class="container">
        <div>
            <a class="goback" href="/donar.html">
                <img src="/img/goback.png">
            </a>
        </div>

        <section class="product-detail">
            <div class="preview">
                <div class="img">
                    <img>
                </div>
                <ul>
                    <li data-image="/img/donar/polo-blanco-1.png">
                        <div class="img">
                            <img src="/img/donar/polo-blanco-1.png">
                        </div>
                    </li>
                </ul>
            </div>

            <div class="details">
                <div class="info">
                    <p class="from">Ccori</p>
                    <p class="name">Polo Ccori - blanco</p>
                    <p class="stock">Unidades disponibles: Sin stock</p>
                    <p class="description">Polo blanco 100% algodón, con serigrafía y diseño de tabla de corte con plus productos y programas sociales.</p>
                    <p class="size">Seleccionar Talla</p>
                    <ul class="sizes">
                        <li>
                            <button class="talla">S</button>
                        </li>
                        <li>
                            <button class="talla">M</button>
                        </li>
                        <li>
                            <button class="talla">L</button>
                        </li>

                    </ul>
                </div>

                <div class="buy">
                    <p class="price">S/ 60.00</p>
                    <div class="buy-controls">
                        <select id="amount">

                        </select>
                        <div id="buy" disabled class="btn">Comprar</div>
                    </div>
                </div>
            </div>

        </section>

        <p class="related_title">TE PUEDE INTERESAR</p>

        <div class="container">
            <section class="store-product-grid">
                <div class="product">
                    <div class="img">
                        <img src="/img/donar/maletin-negro-1.png" alt="Maletín de cuchillos - negro">
                    </div>
                    <div class="info">
                        <h3>Maletín de cuchillos - negro</h2>
                            <p class="price">S/ 600.00</p>
                            <a href="/producto/item-50.html" class="btn">Ver mas</a>
                    </div>
                </div>
                <div class="product">
                    <div class="img">
                        <img src="/img/donar/maletin-cafe-1.png" alt="Maletín de cuchillos - café">
                    </div>
                    <div class="info">
                        <h3>Maletín de cuchillos - café</h2>
                            <p class="price">S/ 600.00</p>
                            <a href="/producto/item-51.html" class="btn">Ver mas</a>
                    </div>
                </div>
                <div class="product">
                    <div class="img">
                        <img src="/img/donar/maletin-beige-1.png" alt="Maletín de cuchillos - beige">
                    </div>
                    <div class="info">
                        <h3>Maletín de cuchillos - beige</h2>
                            <p class="price">S/ 600.00</p>
                            <a href="/producto/item-52.html" class="btn">Ver mas</a>
                    </div>
                </div>
                <div class="product">
                    <div class="img">
                        <img src="/img/donar/polo-negro-1.png" alt="Polo Ccori - negro">
                    </div>
                    <div class="info">
                        <h3>Polo Ccori - negro</h2>
                            <p class="price">S/ 60.00</p>
                            <a href="/producto/item-53.html" class="btn">Ver mas</a>
                    </div>
                </div>
            </section>
        </div>
    </div>

</main>

<?php get_footer(); ?>