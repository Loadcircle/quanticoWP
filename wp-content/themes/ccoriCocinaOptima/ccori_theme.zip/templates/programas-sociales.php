<?php
/* Template Name: Nuestra misión */
get_header();
?>

<main class="programas-sociales-page">

    <div class="container">
        <h2 class="page_title">PROGRAMAS SOCIALES</h2>
        <p class="page_description">A través de diversos programas educativos que concientizan acerca de los beneficios en la aplicación de los fundamentos de la Cocina Óptima, CCORI busca contribuir en el trabajo por alcanzar la seguridad y sostenibilidad alimentaria del Perú.</p>
    </div>

    <div class="tabs">
        <div class="tab-triggers">
            <div class="container"></div>
        </div>
        <div class="tab-pages">
            <div class="tab-page" id="cocinas-bondadosas" data-title="Cocinas bondadosas">
                <div class="green-center-image-hero row">
                    <div class="img">
                        <iframe src="https://www.youtube.com/embed/sDxJMBkisCU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <div class="bg"></div>
                </div>
                <div class="container">
                    <p class="tab-page-description">Es un programa social que tiene el propósito de mejorar la calidad de vida, generando un espacio que empodera y brinda asistencia técnica a las mujeres líderes de los comedores populares en el Perú, capacitándoles en la <strong>optimización del uso de los ingredientes</strong>.

                        En cooperación con la corporación Sodexo Perú y el programa Stop Hunger de Sodexo Mundo, desde el año 2018, se han capacitado a más de <strong>320 mujeres de 22 comedores del distrito de Lurín</strong>, convirtiendo a algunas de estas cocineras en capacitadoras del mismo programa. Cocinas bondadosas tras ser impartido ha logrado la disminución de anemia, sobrepeso, obesidad. Incremento del repertorio de recetas en la dieta, optimización del presupuesto y evitar el desperdicio de alimentos.

                        Dada la contingencia durante el periodo de pandemia, el programa social se ha desarrollado de manera virtual. En forma fructífera, este nuevo formato ha permitido experimentar una nueva <strong>escalabilidad en torno al alcance de más comedores involucrados.</strong> Con tal de finalizar el cierre de las jornadas, se ha ideado el concurso “Cocinas + Ganadoras”, el que en forma lúdica permite evaluar la comprensión de lo impartido por parte de las Cocineras Bondadosas.</p>
                </div>

                <section class="grid-images row">
                    <div class="container">
                        <div class="grid col-3">
                            <div class="img">
                                <img src="/img/programas-sociales/cb-1.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/programas-sociales/cb-2.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/programas-sociales/cb-3.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/programas-sociales/cb-4.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/programas-sociales/cb-5.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/programas-sociales/cb-6.png" alt="">
                            </div>
                        </div>
                    </div>
                </section>
                <div class="container">
                    <div class="news">
                        <h2>NOTICIAS</h2>
                        <button class="trigger-dropdown"></button>
                        <div class="list">
                            <section>
                                <div class="img">
                                    <img src="/img/programas-sociales/cb-n-1.png" alt="Una forma más ecológica de cocinar y cultivar en Perú">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>Una forma más ecológica de cocinar y cultivar en Perú</h2>
                                        <p>Aunque el país sudamericano es famoso por su variada gastronomía, el desperdicio de alimentos es un problema. ¿Podrían los principios de la economía circular cambiar esta situación?</p>
                                    </div>
                                    <a target="_blank" href="https://www.dw.com/es/una-forma-m%C3%A1s-ecol%C3%B3gica-de-cocinar-y-cultivar-en-per%C3%BA/a-57817692" class="btn">Ver más</a>
                                </div>
                            </section>
                            <section>
                                <div class="img">
                                    <img src="/img/programas-sociales/cb-n-2.png" alt="1000 causas fueron repartidas en la cadena solidaria de la Teletón 2021">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>1000 causas fueron repartidas en la cadena solidaria de la Teletón 2021</h2>
                                        <p>El Grupo Sodexo se suma a la Teletón distribuyendo 1000 causas entre Moquegua, Iquitos y Lima, con el propósito de ayudar a los beneficiarios de comedores populares de dichas ciudades, esto, como parte...</p>
                                    </div>
                                    <a target="_blank" href="https://agenciaorbita.org/2021/11/06/1000-causas-fueron-repartidas-en-la-cadena-solidaria-de-la-teleton-2021/" class="btn">Ver más</a>
                                </div>
                            </section>
                        </div>
                    </div>
                    <div class="books">
                        <h2>Papers</h2>
                        <button class="trigger-dropdown"></button>
                        <div class="list">
                            <section>
                                <div class="img">
                                    <img src="/img/programas-sociales/cb-b-1.png" alt="Recetario óptimo">
                                </div>
                                <div class="content">
                                    <h2>Recetario óptimo</h2>
                                    <a target="_blank" href="https://drive.google.com/file/d/12a0vaza5ZFlPpJYMiuJsiDD6yBEeIHPc/view?usp=sharing" class="btn">Ver libro</a>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>

            </div>
            <div class="tab-page" id="cocina-optimista" data-title="Cocina optimista">
                <div class="green-center-image-hero row">
                    <div class="img">
                        <img src="/img/programas-sociales/co-1.png">
                    </div>
                    <div class="bg"></div>
                </div>
                <div class="container">
                    <p class="tab-page-description">Del Alimento Tradicional a la Innovación Gastronómica. Es un libro publicado en junio del año 2019, como parte del macroproyecto <strong>“Círculo de Investigación en Biodiversidad y Gastronomía”</strong> financiado por el FONDECYT (Fondo Nacional de Desarrollo Científico, Tecnológico y de Innovación Tecnológica).

                        En conjunto con la Universidad Peruana Cayetano Heredia (UPCH) y el Instituto de Investigación para el Desarrollo de Francia (IRD), esta publicación presenta los potenciales alimenticios y gastronómicos de los insectos que forman parte de la dieta de los habitantes de la Comunidad de Rumicallpa (San Martin, Perú), y de insectos que pueden ser criados en laboratorio.</p>
                </div>

                <div class="container">
                    <div class="news">
                        <h2>NOTICIAS</h2>
                        <button class="trigger-dropdown"></button>
                        <div class="list">
                            <section>
                                <div class="img">
                                    <img src="/img/programas-sociales/co-n-1.png" alt="El concurso que puso a prueba la sazón de los internos del penal Castro Castro">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>El concurso que puso a prueba la sazón de los internos del penal Castro Castro</h2>
                                        <p>La sazón y creatividad de 32 internos del penal Castro Castro dieron vida al concurso Cocina Optimista, organizado por la ONG Ccori y el INPE. El reto: crear recetas aprovechando al máximo los insumos.</p>
                                    </div>
                                    <a target="_blank" href="https://elcomercio.pe/somos/historias/cocina-que-libera-la-aventura-culinaria-de-los-internos-del-penal-castro-castro-ccori-palmiro-ocampo-gastronomia-noticia/?ref=ecr" class="btn">Ver más</a>
                                </div>
                            </section>
                            <section>
                                <div class="img">
                                    <img src="/img/programas-sociales/co-n-2.png" alt="Concurso Cocina Optimista: historias culinarias desde la prisión ">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>Concurso Cocina Optimista: historias culinarias desde la prisión </h2>
                                        <p>Los sueños de superación de 16 internas del E.P. Anexo Mujeres de Chorrillos sazonaron el concurso organizado por Ccori: Reciclaje Culinario</p>
                                    </div>
                                    <a target="_blank" href="https://elcomercio.pe/gastronomia/peruana/concurso-cocina-optimista-sabor-nueva-oportunidad-noticia-450133-noticia/?ref=ecr" class="btn">Ver más</a>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>

            </div>
            <div class="tab-page" id="malambo-sabroso" data-title="Malambo sabroso">
                <div class="green-center-image-hero row">
                    <div class="img">
                        <iframe src="https://www.youtube.com/embed/6TeSEU8fgEY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <div class="bg"></div>
                </div>
                <div class="container">
                    <p class="tab-page-description">En alianza con la Universidad San Ignacio de Loyola (USIL), se ha desarrollado este proyecto consistente en la realización de talleres de capacitación a mujeres emprendedoras del sector de Malambo. Impulsado por la Municipalidad de Barranco, Malambo Sabroso, busca <strong>revalorizar dicho sector mediante el perfeccionamiento de técnicas culinarias sostenibles</strong>, para que las vecinas puedan aplicar en sus propios emprendimientos.</p>
                </div>

                <section class="grid-images row">
                    <div class="container">
                        <div class="grid col-3">
                            <div class="img">
                                <img src="/img/programas-sociales/ms-1.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/programas-sociales/ms-2.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/programas-sociales/ms-3.png" alt="">
                            </div>
                        </div>
                    </div>
                </section>
                <div class="container">
                    <div class="news">
                        <h2>NOTICIAS</h2>
                        <button class="trigger-dropdown"></button>
                        <div class="list">
                            <section>
                                <div class="img">
                                    <img src="/img/programas-sociales/ms-n-1.png" alt="¿Quieres disfrutar de un recorrido cultural en Barranco? Conoce la propuesta de 'Barranco Camina'">
                                </div>
                                <div class="content">
                                    <div>
                                        <h2>¿Quieres disfrutar de un recorrido cultural en Barranco? Conoce la propuesta de 'Barranco Camina'</h2>
                                        <p>'Barranco Camina' es el recorrido cultural impulsado por la Municipalidad de Barranco. Esta actividad se realiza hoy y mañana.</p>
                                    </div>
                                    <a target="_blank" href="https://peru21.pe/lima/quieres-disfrutar-recorrido-cultural-barranco-conoce-propuesta-barranco-camina-494146-noticia/" class="btn">Ver más</a>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>

            </div>
            <div class="tab-page" id="talleres-vivenciales" data-title="Talleres vivenciales">
                <div class="green-center-image-hero row">
                    <div class="img">
                        <iframe src="https://www.youtube.com/embed/bNWEFzTZ-H8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <div class="bg"></div>
                </div>
                <div class="container">
                    <p class="tab-page-description">Junto a la Universidad del Pacífico (UP), orientado a <strong>fomentar la concientización en relación a los alimentos</strong> por parte de los alumnos de diversas carreras, CCORI ha realizado capacitaciones que van desde el reconocimiento y recuperación en mercados, la optimización gastronómica, y la concienciación de la labor social de los comedores. </p>
                </div>

                <section class="grid-images row">
                    <div class="container">
                        <div class="grid col-3">
                            <div class="img">
                                <img src="/img/programas-sociales/tv-1.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/programas-sociales/tv-2.png" alt="">
                            </div>
                            <div class="img">
                                <img src="/img/programas-sociales/tv-3.png" alt="">
                            </div>
                        </div>
                    </div>
                </section>

            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>