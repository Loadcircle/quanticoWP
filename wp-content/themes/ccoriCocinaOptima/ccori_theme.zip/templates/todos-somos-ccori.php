<?php
/* Template Name: Todos somos ccori */
get_header();
?>

<main class="todos-somos-ccori-page">

    <div class="container">
        <h2 class="page_title">TODOS SOMOS CCORI</h2>
        <p class="page_description">Cada año en el mundo, una tercera parte de los alimentos se pierde y desperdicia. En paralelo, 800 millones de personas padecen hambre. Desde el 2013, CCORI ha desarrollado metodologías gastronómicas denominadas <strong>COCINA ÓPTIMA y RECICLAJE CULINARIO</strong>, cuyo objetivo es el máximo aprovechamiento de los alimentos.

            Mediante la investigación de técnicas culinarias modernas y ancestrales, sus factores culturales y su historia, e integrando conocimientos obtenidos de fuentes y colaboradores interdisciplinarios, CCORI, es la primera organización en Latinoamérica dedicada a desarrollar una Cocina Óptima, <strong>una cocina que optimiza los alimentos en sabor, textura, rendimiento y nutrientes.</strong></p>
    </div>

    <section class="green-hero-video row">
        <div class="container">
            <h2>CONOCE MÁS DE LO QUE HACEMOS</h2>
            <div class="video">
                <video controls poster="https://res.cloudinary.com/onfireco/image/upload/v1649209891/ccori/cocina_optima/preview_dvpvnp.png">
                    <source src="https://res.cloudinary.com/onfireco/video/upload/v1649209474/ccori/cocina_optima/video.mp4" type="video/mp4">
                </video>
            </div>
        </div>

        <div class="bg"></div>
    </section>
    <section class="image-info-block row">
        <div class="container">

            <h2>NUESTROS FUNDADORES</h2>

            <div class="content">
                <div class="img">
                    <img src="/img/tsc/1.png" alt="NUESTROS FUNDADORES">
                    <p>Palmiro Ocampo y Anyell San Miguel</p>
                </div>
                <div class="info">
                    <p>Palmiro y Anyell son una joven pareja peruana que decidieron hacer las cosas distinto.

                        Él, chef de carrera con amplio y reconocido recorrido en el extranjero, y élla, ingeniera especialista en la gestión de proyectos basados en tecnologías de la información; identificando diversas problemáticas asociadas a la actividad alimentaria del Perú y el mundo, fundan Ccori.</p>
                </div>
            </div>
        </div>
    </section>
    <section class="grid-images row">
        <div class="container">
            <h2>NUESTRA TRIBU</h2>
            <div class="grid col-3">
                <div class="img">
                    <img src="/img/tsc/m-1.png" alt="Nathalia - Comunicaciones">
                    <p>Nathalia - Comunicaciones</p>
                </div>
                <div class="img">
                    <img src="/img/tsc/m-2.png" alt="Ronald - Coordinación de proyectos">
                    <p>Ronald - Coordinación de proyectos</p>
                </div>
                <div class="img">
                    <img src="/img/tsc/m-3.png" alt="Rocio - Nutricionista">
                    <p>Rocio - Nutricionista</p>
                </div>
                <div class="img">
                    <img src="/img/tsc/m-4.png" alt="Enma - Cocinera docente">
                    <p>Enma - Cocinera docente</p>
                </div>
                <div class="img">
                    <img src="/img/tsc/m-5.png" alt="Adeli - Cocinera docente">
                    <p>Adeli - Cocinera docente</p>
                </div>
                <div class="img">
                    <img src="/img/tsc/m-6.png" alt="Lola - Cocinera bondadosa">
                    <p>Lola - Cocinera bondadosa</p>
                </div>
            </div>
        </div>
    </section>
    <section class="grid-text row">
        <div class="container">
            <h2>NUESTROS COLABORADORES</h2>
            <button class="trigger-dropdown"></button>
            <div class="grid txt">
                <div class="card text-center">
                    <p class="title">Michel Sauvain</p>
                    <p class="label">Dr. Bio Químico</p>
                </div>
                <div class="card text-center">
                    <p class="title">Rosario Rojas</p>
                    <p class="label">Doctora</p>
                </div>
                <div class="card text-center">
                    <p class="title">Nancy Chasquibol</p>
                    <p class="label">Doctora</p>
                </div>
                <div class="card text-center">
                    <p class="title">Gonzalo Tejada</p>
                    <p class="label">Sociólogo</p>
                </div>
                <div class="card text-center">
                    <p class="title">Luis Casas</p>
                    <p class="label">Gastrónomo</p>
                </div>
                <div class="card text-center">
                    <p class="title">Anthony Castro</p>
                    <p class="label">Cocinero</p>
                </div>
                <div class="card text-center">
                    <p class="title">Miguel Saenz</p>
                    <p class="label">Cocinero docente</p>
                </div>
                <div class="card text-center">
                    <p class="title">Romina Vera</p>
                    <p class="label">Fotógrafa</p>
                </div>
                <div class="card text-center">
                    <p class="title">Geronimo Campos</p>
                    <p class="label">Director de arte</p>
                </div>
                <div class="card text-center">
                    <p class="title">Elisabeth</p>
                    <p class="label">Diseñadora social</p>
                </div>
                <div class="card text-center">
                    <p class="title">Rudolph Castro</p>
                    <p class="label">Artista</p>
                </div>
                <div class="card text-center">
                    <p class="title">Alfonso de los Heros</p>
                    <p class="label">Ceo Sedexo</p>
                </div>
                <div class="card text-center">
                    <p class="title">Jefferson</p>
                    <p class="label">Gerente responsabilidad social</p>
                </div>
            </div>
        </div>
    </section>


    <section class="grid-image-cards-dropdown row">
        <div class="container">
            <h2>NUESTROS SOCIOS/ALIADOS</h2>
            <button class="trigger-dropdown"></button>
            <div class="grid">
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-1.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-2.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-3.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-4.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-5.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-6.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-7.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-8.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-9.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-10.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-11.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-12.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-13.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-14.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-15.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-16.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-17.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-18.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-19.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-20.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-21.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-22.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-23.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-24.png);"></div>
                </div>
                <div class="img-card">
                    <div class="img" style="background-image: url(/img/tsc/a-25.png);"></div>
                </div>
            </div>
        </div>
    </section>

    <section class="green-block row">
        <div class="container text-center">
            <h2>¿QUIERES SUMARTE A NUESTRA MISIÓN?</h2>
            <a class="btn" href="#">Quiero sumarme</a>
        </div>
    </section>
</main>


<?php get_footer(); ?>